﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Linx_Seller_QA.App_Code
{
    public class AttachaPersonaliza
    {




    }
}